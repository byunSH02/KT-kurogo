function scrollToTop() {
	scrollTo(0,1); 
}

function onDOMChange() {
  // Not needed for compliant
}
