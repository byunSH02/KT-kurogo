function moduleInit() {
    setupSplitViewForListAndDetail('newsHeader', 'stories', 'storyDetailWrapper', 'storyDetail');
}
