<?php
/**
  * @package Module
  * @subpackage Info
  */

/**
  * @package Module
  * @subpackage Info
  */
class InfoWebModule extends WebModule {
  protected $id = 'info';
     
  protected function initializeForPage() {
    // Just a static page
  }
}
