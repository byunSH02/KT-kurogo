################
Customize Module
################

The customize module allows users to change the ordering or display of modules on your site's home
screen. The module uses *cookies* on the user's browser to save the results, so the effects are limited
to the user's device/browser.

=============
Configuration
=============

There are no configurable parameters in this module. If you do not wish for users to be able to adjust
the home screen, you can disable this module.