#################
Included Modules
#################

There are a number of modules that are included inside the distribution of Kurogo. In this section 
you can learn more about these modules, what they do and how to configure them.

.. toctree::
   :maxdepth: 1

   modulehome
   moduleinfo
   modulepeople
   modulevideo
   modulecalendar
   modulenews
   moduleemergency
   modulemap
   modulelinks
   modulecontent
   moduleurl
   modulecustomize
   moduleabout
   modulelogin
   modulestats
   
