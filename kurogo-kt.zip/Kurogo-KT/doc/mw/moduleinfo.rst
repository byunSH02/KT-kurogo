###########
Info Module
###########

The info module is, by default, shown to users who visit the site using a desktop browser. The intent
it to provide users with information about your site. The default implementation contains no code, and
the design included with the reference site is merely an example. You should create your own page that
matches the brand and styling of your site.

If you would prefer to have users see the home page and not the info module from a desktop browser,
you can remove the *DEFAULT-COMPLIANT-COMPUTER* value in the *[urls]* section of your site's
*site.ini* file and ensure the *DEFAULT* value is set to home.

