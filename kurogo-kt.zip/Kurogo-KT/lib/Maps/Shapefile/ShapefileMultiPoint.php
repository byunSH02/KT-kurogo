<?php

class ShapefileMultiPoint extends ShapefileGeometry
{
}
