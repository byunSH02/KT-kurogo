<?php

class KMLDataController extends MapDataController
{
    protected $parserClass = 'KMLDataParser';
}

