<?php

// basically the same thing as LineString but forms a closed loop
class KMLLinearRing extends KMLLineString {
    
}
