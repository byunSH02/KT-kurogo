<?php

// implemented by map categories, which have no geometry
interface MapListElement
{
    public function getTitle();
    public function getSubtitle();
}

