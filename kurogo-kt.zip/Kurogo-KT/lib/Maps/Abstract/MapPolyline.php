<?php

interface MapPolyline extends MapGeometry
{
    public function getPoints();
}

