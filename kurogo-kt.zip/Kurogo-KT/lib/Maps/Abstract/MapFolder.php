<?php

interface MapFolder
{
    public function getListItems();
    public function getAllPlacemarks();
    public function getChildCategories();
}
