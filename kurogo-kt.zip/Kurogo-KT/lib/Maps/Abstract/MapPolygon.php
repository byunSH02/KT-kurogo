<?php

interface MapPolygon extends MapGeometry
{
    public function getRings();
}

